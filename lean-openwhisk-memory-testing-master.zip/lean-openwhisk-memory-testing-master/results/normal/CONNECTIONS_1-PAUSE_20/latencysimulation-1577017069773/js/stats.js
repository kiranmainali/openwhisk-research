var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "412",
        "ok": "412",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "40",
        "ok": "40",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "9150",
        "ok": "9150",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "396",
        "ok": "396",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1214",
        "ok": "1214",
        "ko": "-"
    },
    "percentiles1": {
        "total": "108",
        "ok": "108",
        "ko": "-"
    },
    "percentiles2": {
        "total": "151",
        "ok": "151",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3111",
        "ok": "3111",
        "ko": "-"
    },
    "percentiles4": {
        "total": "8028",
        "ok": "8028",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 387,
        "percentage": 94
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 25,
        "percentage": 6
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "2.395",
        "ok": "2.395",
        "ko": "-"
    }
},
contents: {
"req_create-nodejs-d-862fc": {
        type: "REQUEST",
        name: "Create nodejs:default action",
path: "Create nodejs:default action",
pathFormatted: "req_create-nodejs-d-862fc",
stats: {
    "name": "Create nodejs:default action",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "649",
        "ok": "649",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "649",
        "ok": "649",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "649",
        "ok": "649",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "649",
        "ok": "649",
        "ko": "-"
    },
    "percentiles2": {
        "total": "649",
        "ok": "649",
        "ko": "-"
    },
    "percentiles3": {
        "total": "649",
        "ok": "649",
        "ko": "-"
    },
    "percentiles4": {
        "total": "649",
        "ok": "649",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.006",
        "ok": "0.006",
        "ko": "-"
    }
}
    },"req_cold-nodejs-def-98d5b": {
        type: "REQUEST",
        name: "Cold nodejs:default invocation",
path: "Cold nodejs:default invocation",
pathFormatted: "req_cold-nodejs-def-98d5b",
stats: {
    "name": "Cold nodejs:default invocation",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3671",
        "ok": "3671",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3671",
        "ok": "3671",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3671",
        "ok": "3671",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3671",
        "ok": "3671",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3671",
        "ok": "3671",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3671",
        "ok": "3671",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3671",
        "ok": "3671",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 1,
        "percentage": 100
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.006",
        "ok": "0.006",
        "ko": "-"
    }
}
    },"req_warm-nodejs-def-e02a1": {
        type: "REQUEST",
        name: "Warm nodejs:default invocation",
path: "Warm nodejs:default invocation",
pathFormatted: "req_warm-nodejs-def-e02a1",
stats: {
    "name": "Warm nodejs:default invocation",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "52",
        "ok": "52",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4613",
        "ok": "4613",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "316",
        "ok": "316",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "769",
        "ok": "769",
        "ko": "-"
    },
    "percentiles1": {
        "total": "121",
        "ok": "121",
        "ko": "-"
    },
    "percentiles2": {
        "total": "150",
        "ok": "150",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2740",
        "ok": "2740",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3383",
        "ok": "3383",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 94,
        "percentage": 94
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 6,
        "percentage": 6
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.581",
        "ok": "0.581",
        "ko": "-"
    }
}
    },"req_delete-nodejs-d-591c6": {
        type: "REQUEST",
        name: "Delete nodejs:default action",
path: "Delete nodejs:default action",
pathFormatted: "req_delete-nodejs-d-591c6",
stats: {
    "name": "Delete nodejs:default action",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "107",
        "ok": "107",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "107",
        "ok": "107",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "107",
        "ok": "107",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "107",
        "ok": "107",
        "ko": "-"
    },
    "percentiles2": {
        "total": "107",
        "ok": "107",
        "ko": "-"
    },
    "percentiles3": {
        "total": "107",
        "ok": "107",
        "ko": "-"
    },
    "percentiles4": {
        "total": "107",
        "ok": "107",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.006",
        "ok": "0.006",
        "ko": "-"
    }
}
    },"req_create-python-d-dd896": {
        type: "REQUEST",
        name: "Create python:default action",
path: "Create python:default action",
pathFormatted: "req_create-python-d-dd896",
stats: {
    "name": "Create python:default action",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "171",
        "ok": "171",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "171",
        "ok": "171",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "171",
        "ok": "171",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "171",
        "ok": "171",
        "ko": "-"
    },
    "percentiles2": {
        "total": "171",
        "ok": "171",
        "ko": "-"
    },
    "percentiles3": {
        "total": "171",
        "ok": "171",
        "ko": "-"
    },
    "percentiles4": {
        "total": "171",
        "ok": "171",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.006",
        "ok": "0.006",
        "ko": "-"
    }
}
    },"req_cold-python-def-b7e74": {
        type: "REQUEST",
        name: "Cold python:default invocation",
path: "Cold python:default invocation",
pathFormatted: "req_cold-python-def-b7e74",
stats: {
    "name": "Cold python:default invocation",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "4141",
        "ok": "4141",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4141",
        "ok": "4141",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "4141",
        "ok": "4141",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "4141",
        "ok": "4141",
        "ko": "-"
    },
    "percentiles2": {
        "total": "4141",
        "ok": "4141",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4141",
        "ok": "4141",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4141",
        "ok": "4141",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 1,
        "percentage": 100
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.006",
        "ok": "0.006",
        "ko": "-"
    }
}
    },"req_warm-python-def-83719": {
        type: "REQUEST",
        name: "Warm python:default invocation",
path: "Warm python:default invocation",
pathFormatted: "req_warm-python-def-83719",
stats: {
    "name": "Warm python:default invocation",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "42",
        "ok": "42",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3678",
        "ok": "3678",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "269",
        "ok": "269",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "702",
        "ok": "702",
        "ko": "-"
    },
    "percentiles1": {
        "total": "100",
        "ok": "100",
        "ko": "-"
    },
    "percentiles2": {
        "total": "145",
        "ok": "145",
        "ko": "-"
    },
    "percentiles3": {
        "total": "433",
        "ok": "433",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3446",
        "ok": "3446",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 95,
        "percentage": 95
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 5,
        "percentage": 5
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.581",
        "ok": "0.581",
        "ko": "-"
    }
}
    },"req_delete-python-d-b756d": {
        type: "REQUEST",
        name: "Delete python:default action",
path: "Delete python:default action",
pathFormatted: "req_delete-python-d-b756d",
stats: {
    "name": "Delete python:default action",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "129",
        "ok": "129",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "129",
        "ok": "129",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "129",
        "ok": "129",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "129",
        "ok": "129",
        "ko": "-"
    },
    "percentiles2": {
        "total": "129",
        "ok": "129",
        "ko": "-"
    },
    "percentiles3": {
        "total": "129",
        "ok": "129",
        "ko": "-"
    },
    "percentiles4": {
        "total": "129",
        "ok": "129",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.006",
        "ok": "0.006",
        "ko": "-"
    }
}
    },"req_create-swift-de-7074b": {
        type: "REQUEST",
        name: "Create swift:default action",
path: "Create swift:default action",
pathFormatted: "req_create-swift-de-7074b",
stats: {
    "name": "Create swift:default action",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "82",
        "ok": "82",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "82",
        "ok": "82",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "82",
        "ok": "82",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "82",
        "ok": "82",
        "ko": "-"
    },
    "percentiles2": {
        "total": "82",
        "ok": "82",
        "ko": "-"
    },
    "percentiles3": {
        "total": "82",
        "ok": "82",
        "ko": "-"
    },
    "percentiles4": {
        "total": "82",
        "ok": "82",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.006",
        "ok": "0.006",
        "ko": "-"
    }
}
    },"req_cold-swift-defa-d2682": {
        type: "REQUEST",
        name: "Cold swift:default invocation",
path: "Cold swift:default invocation",
pathFormatted: "req_cold-swift-defa-d2682",
stats: {
    "name": "Cold swift:default invocation",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "8539",
        "ok": "8539",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "8539",
        "ok": "8539",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "8539",
        "ok": "8539",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "8539",
        "ok": "8539",
        "ko": "-"
    },
    "percentiles2": {
        "total": "8539",
        "ok": "8539",
        "ko": "-"
    },
    "percentiles3": {
        "total": "8539",
        "ok": "8539",
        "ko": "-"
    },
    "percentiles4": {
        "total": "8539",
        "ok": "8539",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 1,
        "percentage": 100
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.006",
        "ok": "0.006",
        "ko": "-"
    }
}
    },"req_warm-swift-defa-7be77": {
        type: "REQUEST",
        name: "Warm swift:default invocation",
path: "Warm swift:default invocation",
pathFormatted: "req_warm-swift-defa-7be77",
stats: {
    "name": "Warm swift:default invocation",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "40",
        "ok": "40",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "9150",
        "ok": "9150",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "524",
        "ok": "524",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1812",
        "ok": "1812",
        "ko": "-"
    },
    "percentiles1": {
        "total": "99",
        "ok": "99",
        "ko": "-"
    },
    "percentiles2": {
        "total": "133",
        "ok": "133",
        "ko": "-"
    },
    "percentiles3": {
        "total": "842",
        "ok": "842",
        "ko": "-"
    },
    "percentiles4": {
        "total": "8634",
        "ok": "8634",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 95,
        "percentage": 95
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 5,
        "percentage": 5
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.581",
        "ok": "0.581",
        "ko": "-"
    }
}
    },"req_delete-swift-de-b18ce": {
        type: "REQUEST",
        name: "Delete swift:default action",
path: "Delete swift:default action",
pathFormatted: "req_delete-swift-de-b18ce",
stats: {
    "name": "Delete swift:default action",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "355",
        "ok": "355",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "355",
        "ok": "355",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "355",
        "ok": "355",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "355",
        "ok": "355",
        "ko": "-"
    },
    "percentiles2": {
        "total": "355",
        "ok": "355",
        "ko": "-"
    },
    "percentiles3": {
        "total": "355",
        "ok": "355",
        "ko": "-"
    },
    "percentiles4": {
        "total": "355",
        "ok": "355",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.006",
        "ok": "0.006",
        "ko": "-"
    }
}
    },"req_create-java-def-21f87": {
        type: "REQUEST",
        name: "Create java:default action",
path: "Create java:default action",
pathFormatted: "req_create-java-def-21f87",
stats: {
    "name": "Create java:default action",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "190",
        "ok": "190",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "190",
        "ok": "190",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "190",
        "ok": "190",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "190",
        "ok": "190",
        "ko": "-"
    },
    "percentiles2": {
        "total": "190",
        "ok": "190",
        "ko": "-"
    },
    "percentiles3": {
        "total": "190",
        "ok": "190",
        "ko": "-"
    },
    "percentiles4": {
        "total": "190",
        "ok": "190",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.006",
        "ok": "0.006",
        "ko": "-"
    }
}
    },"req_cold-java-defau-05709": {
        type: "REQUEST",
        name: "Cold java:default invocation",
path: "Cold java:default invocation",
pathFormatted: "req_cold-java-defau-05709",
stats: {
    "name": "Cold java:default invocation",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3482",
        "ok": "3482",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3482",
        "ok": "3482",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3482",
        "ok": "3482",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3482",
        "ok": "3482",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3482",
        "ok": "3482",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3482",
        "ok": "3482",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3482",
        "ok": "3482",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 1,
        "percentage": 100
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.006",
        "ok": "0.006",
        "ko": "-"
    }
}
    },"req_warm-java-defau-1eebf": {
        type: "REQUEST",
        name: "Warm java:default invocation",
path: "Warm java:default invocation",
pathFormatted: "req_warm-java-defau-1eebf",
stats: {
    "name": "Warm java:default invocation",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "53",
        "ok": "53",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "4509",
        "ok": "4509",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "306",
        "ok": "306",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "805",
        "ok": "805",
        "ko": "-"
    },
    "percentiles1": {
        "total": "110",
        "ok": "110",
        "ko": "-"
    },
    "percentiles2": {
        "total": "155",
        "ok": "155",
        "ko": "-"
    },
    "percentiles3": {
        "total": "531",
        "ok": "531",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4000",
        "ok": "4000",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 95,
        "percentage": 95
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 5,
        "percentage": 5
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.581",
        "ok": "0.581",
        "ko": "-"
    }
}
    },"req_delete-java-def-92688": {
        type: "REQUEST",
        name: "Delete java:default action",
path: "Delete java:default action",
pathFormatted: "req_delete-java-def-92688",
stats: {
    "name": "Delete java:default action",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "106",
        "ok": "106",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "106",
        "ok": "106",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "106",
        "ok": "106",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "106",
        "ok": "106",
        "ko": "-"
    },
    "percentiles2": {
        "total": "106",
        "ok": "106",
        "ko": "-"
    },
    "percentiles3": {
        "total": "106",
        "ok": "106",
        "ko": "-"
    },
    "percentiles4": {
        "total": "106",
        "ok": "106",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.006",
        "ok": "0.006",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
