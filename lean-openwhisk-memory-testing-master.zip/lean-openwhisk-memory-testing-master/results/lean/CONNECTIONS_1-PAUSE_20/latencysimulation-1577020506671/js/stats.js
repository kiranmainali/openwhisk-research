var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "412",
        "ok": "412",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "17",
        "ok": "17",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "7913",
        "ok": "7913",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "308",
        "ok": "308",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "957",
        "ok": "957",
        "ko": "-"
    },
    "percentiles1": {
        "total": "52",
        "ok": "52",
        "ko": "-"
    },
    "percentiles2": {
        "total": "81",
        "ok": "81",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2503",
        "ok": "2503",
        "ko": "-"
    },
    "percentiles4": {
        "total": "5157",
        "ok": "5157",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 383,
        "percentage": 93
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 29,
        "percentage": 7
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "3.029",
        "ok": "3.029",
        "ko": "-"
    }
},
contents: {
"req_create-nodejs-d-862fc": {
        type: "REQUEST",
        name: "Create nodejs:default action",
path: "Create nodejs:default action",
pathFormatted: "req_create-nodejs-d-862fc",
stats: {
    "name": "Create nodejs:default action",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "198",
        "ok": "198",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "198",
        "ok": "198",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "198",
        "ok": "198",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "198",
        "ok": "198",
        "ko": "-"
    },
    "percentiles2": {
        "total": "198",
        "ok": "198",
        "ko": "-"
    },
    "percentiles3": {
        "total": "198",
        "ok": "198",
        "ko": "-"
    },
    "percentiles4": {
        "total": "198",
        "ok": "198",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.007",
        "ok": "0.007",
        "ko": "-"
    }
}
    },"req_cold-nodejs-def-98d5b": {
        type: "REQUEST",
        name: "Cold nodejs:default invocation",
path: "Cold nodejs:default invocation",
pathFormatted: "req_cold-nodejs-def-98d5b",
stats: {
    "name": "Cold nodejs:default invocation",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "2664",
        "ok": "2664",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2664",
        "ok": "2664",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2664",
        "ok": "2664",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "2664",
        "ok": "2664",
        "ko": "-"
    },
    "percentiles2": {
        "total": "2664",
        "ok": "2664",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2664",
        "ok": "2664",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2664",
        "ok": "2664",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 1,
        "percentage": 100
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.007",
        "ok": "0.007",
        "ko": "-"
    }
}
    },"req_warm-nodejs-def-e02a1": {
        type: "REQUEST",
        name: "Warm nodejs:default invocation",
path: "Warm nodejs:default invocation",
pathFormatted: "req_warm-nodejs-def-e02a1",
stats: {
    "name": "Warm nodejs:default invocation",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "24",
        "ok": "24",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "7913",
        "ok": "7913",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "294",
        "ok": "294",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "934",
        "ok": "934",
        "ko": "-"
    },
    "percentiles1": {
        "total": "86",
        "ok": "86",
        "ko": "-"
    },
    "percentiles2": {
        "total": "160",
        "ok": "160",
        "ko": "-"
    },
    "percentiles3": {
        "total": "584",
        "ok": "584",
        "ko": "-"
    },
    "percentiles4": {
        "total": "4174",
        "ok": "4174",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 95,
        "percentage": 95
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 5,
        "percentage": 5
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.735",
        "ok": "0.735",
        "ko": "-"
    }
}
    },"req_delete-nodejs-d-591c6": {
        type: "REQUEST",
        name: "Delete nodejs:default action",
path: "Delete nodejs:default action",
pathFormatted: "req_delete-nodejs-d-591c6",
stats: {
    "name": "Delete nodejs:default action",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "162",
        "ok": "162",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "162",
        "ok": "162",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "162",
        "ok": "162",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "162",
        "ok": "162",
        "ko": "-"
    },
    "percentiles2": {
        "total": "162",
        "ok": "162",
        "ko": "-"
    },
    "percentiles3": {
        "total": "162",
        "ok": "162",
        "ko": "-"
    },
    "percentiles4": {
        "total": "162",
        "ok": "162",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.007",
        "ok": "0.007",
        "ko": "-"
    }
}
    },"req_create-python-d-dd896": {
        type: "REQUEST",
        name: "Create python:default action",
path: "Create python:default action",
pathFormatted: "req_create-python-d-dd896",
stats: {
    "name": "Create python:default action",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "228",
        "ok": "228",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "228",
        "ok": "228",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "228",
        "ok": "228",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "228",
        "ok": "228",
        "ko": "-"
    },
    "percentiles2": {
        "total": "228",
        "ok": "228",
        "ko": "-"
    },
    "percentiles3": {
        "total": "228",
        "ok": "228",
        "ko": "-"
    },
    "percentiles4": {
        "total": "228",
        "ok": "228",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.007",
        "ok": "0.007",
        "ko": "-"
    }
}
    },"req_cold-python-def-b7e74": {
        type: "REQUEST",
        name: "Cold python:default invocation",
path: "Cold python:default invocation",
pathFormatted: "req_cold-python-def-b7e74",
stats: {
    "name": "Cold python:default invocation",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3661",
        "ok": "3661",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3661",
        "ok": "3661",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3661",
        "ok": "3661",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3661",
        "ok": "3661",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3661",
        "ok": "3661",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3661",
        "ok": "3661",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3661",
        "ok": "3661",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 1,
        "percentage": 100
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.007",
        "ok": "0.007",
        "ko": "-"
    }
}
    },"req_warm-python-def-83719": {
        type: "REQUEST",
        name: "Warm python:default invocation",
path: "Warm python:default invocation",
pathFormatted: "req_warm-python-def-83719",
stats: {
    "name": "Warm python:default invocation",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "21",
        "ok": "21",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3039",
        "ok": "3039",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "234",
        "ok": "234",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "659",
        "ok": "659",
        "ko": "-"
    },
    "percentiles1": {
        "total": "49",
        "ok": "49",
        "ko": "-"
    },
    "percentiles2": {
        "total": "73",
        "ok": "73",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2459",
        "ok": "2459",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2880",
        "ok": "2880",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 93,
        "percentage": 93
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 7,
        "percentage": 7
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.735",
        "ok": "0.735",
        "ko": "-"
    }
}
    },"req_delete-python-d-b756d": {
        type: "REQUEST",
        name: "Delete python:default action",
path: "Delete python:default action",
pathFormatted: "req_delete-python-d-b756d",
stats: {
    "name": "Delete python:default action",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "93",
        "ok": "93",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "93",
        "ok": "93",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "93",
        "ok": "93",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "93",
        "ok": "93",
        "ko": "-"
    },
    "percentiles2": {
        "total": "93",
        "ok": "93",
        "ko": "-"
    },
    "percentiles3": {
        "total": "93",
        "ok": "93",
        "ko": "-"
    },
    "percentiles4": {
        "total": "93",
        "ok": "93",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.007",
        "ok": "0.007",
        "ko": "-"
    }
}
    },"req_create-swift-de-7074b": {
        type: "REQUEST",
        name: "Create swift:default action",
path: "Create swift:default action",
pathFormatted: "req_create-swift-de-7074b",
stats: {
    "name": "Create swift:default action",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "102",
        "ok": "102",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "102",
        "ok": "102",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "102",
        "ok": "102",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "102",
        "ok": "102",
        "ko": "-"
    },
    "percentiles2": {
        "total": "102",
        "ok": "102",
        "ko": "-"
    },
    "percentiles3": {
        "total": "102",
        "ok": "102",
        "ko": "-"
    },
    "percentiles4": {
        "total": "102",
        "ok": "102",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.007",
        "ok": "0.007",
        "ko": "-"
    }
}
    },"req_cold-swift-defa-d2682": {
        type: "REQUEST",
        name: "Cold swift:default invocation",
path: "Cold swift:default invocation",
pathFormatted: "req_cold-swift-defa-d2682",
stats: {
    "name": "Cold swift:default invocation",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "5487",
        "ok": "5487",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "5487",
        "ok": "5487",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "5487",
        "ok": "5487",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "5487",
        "ok": "5487",
        "ko": "-"
    },
    "percentiles2": {
        "total": "5487",
        "ok": "5487",
        "ko": "-"
    },
    "percentiles3": {
        "total": "5487",
        "ok": "5487",
        "ko": "-"
    },
    "percentiles4": {
        "total": "5487",
        "ok": "5487",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 1,
        "percentage": 100
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.007",
        "ok": "0.007",
        "ko": "-"
    }
}
    },"req_warm-swift-defa-7be77": {
        type: "REQUEST",
        name: "Warm swift:default invocation",
path: "Warm swift:default invocation",
pathFormatted: "req_warm-swift-defa-7be77",
stats: {
    "name": "Warm swift:default invocation",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "17",
        "ok": "17",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "5866",
        "ok": "5866",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "350",
        "ok": "350",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1222",
        "ok": "1222",
        "ko": "-"
    },
    "percentiles1": {
        "total": "39",
        "ok": "39",
        "ko": "-"
    },
    "percentiles2": {
        "total": "60",
        "ok": "60",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4767",
        "ok": "4767",
        "ko": "-"
    },
    "percentiles4": {
        "total": "5436",
        "ok": "5436",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 94,
        "percentage": 94
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 6,
        "percentage": 6
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.735",
        "ok": "0.735",
        "ko": "-"
    }
}
    },"req_delete-swift-de-b18ce": {
        type: "REQUEST",
        name: "Delete swift:default action",
path: "Delete swift:default action",
pathFormatted: "req_delete-swift-de-b18ce",
stats: {
    "name": "Delete swift:default action",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "63",
        "ok": "63",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "63",
        "ok": "63",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "63",
        "ok": "63",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "63",
        "ok": "63",
        "ko": "-"
    },
    "percentiles2": {
        "total": "63",
        "ok": "63",
        "ko": "-"
    },
    "percentiles3": {
        "total": "63",
        "ok": "63",
        "ko": "-"
    },
    "percentiles4": {
        "total": "63",
        "ok": "63",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.007",
        "ok": "0.007",
        "ko": "-"
    }
}
    },"req_create-java-def-21f87": {
        type: "REQUEST",
        name: "Create java:default action",
path: "Create java:default action",
pathFormatted: "req_create-java-def-21f87",
stats: {
    "name": "Create java:default action",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "77",
        "ok": "77",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "77",
        "ok": "77",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "77",
        "ok": "77",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "77",
        "ok": "77",
        "ko": "-"
    },
    "percentiles2": {
        "total": "77",
        "ok": "77",
        "ko": "-"
    },
    "percentiles3": {
        "total": "77",
        "ok": "77",
        "ko": "-"
    },
    "percentiles4": {
        "total": "77",
        "ok": "77",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.007",
        "ok": "0.007",
        "ko": "-"
    }
}
    },"req_cold-java-defau-05709": {
        type: "REQUEST",
        name: "Cold java:default invocation",
path: "Cold java:default invocation",
pathFormatted: "req_cold-java-defau-05709",
stats: {
    "name": "Cold java:default invocation",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "3041",
        "ok": "3041",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3041",
        "ok": "3041",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3041",
        "ok": "3041",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3041",
        "ok": "3041",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3041",
        "ok": "3041",
        "ko": "-"
    },
    "percentiles3": {
        "total": "3041",
        "ok": "3041",
        "ko": "-"
    },
    "percentiles4": {
        "total": "3041",
        "ok": "3041",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 1,
        "percentage": 100
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.007",
        "ok": "0.007",
        "ko": "-"
    }
}
    },"req_warm-java-defau-1eebf": {
        type: "REQUEST",
        name: "Warm java:default invocation",
path: "Warm java:default invocation",
pathFormatted: "req_warm-java-defau-1eebf",
stats: {
    "name": "Warm java:default invocation",
    "numberOfRequests": {
        "total": "100",
        "ok": "100",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "20",
        "ok": "20",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3152",
        "ok": "3152",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "231",
        "ok": "231",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "669",
        "ok": "669",
        "ko": "-"
    },
    "percentiles1": {
        "total": "48",
        "ok": "48",
        "ko": "-"
    },
    "percentiles2": {
        "total": "69",
        "ok": "69",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2479",
        "ok": "2479",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2846",
        "ok": "2846",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 93,
        "percentage": 93
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 7,
        "percentage": 7
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.735",
        "ok": "0.735",
        "ko": "-"
    }
}
    },"req_delete-java-def-92688": {
        type: "REQUEST",
        name: "Delete java:default action",
path: "Delete java:default action",
pathFormatted: "req_delete-java-def-92688",
stats: {
    "name": "Delete java:default action",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "41",
        "ok": "41",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "41",
        "ok": "41",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "41",
        "ok": "41",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "41",
        "ok": "41",
        "ko": "-"
    },
    "percentiles2": {
        "total": "41",
        "ok": "41",
        "ko": "-"
    },
    "percentiles3": {
        "total": "41",
        "ok": "41",
        "ko": "-"
    },
    "percentiles4": {
        "total": "41",
        "ok": "41",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 1,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.007",
        "ok": "0.007",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
